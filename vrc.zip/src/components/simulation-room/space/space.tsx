import { useSelector } from "react-redux";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Sky, Stars } from "@react-three/drei";
import { IStoreRoomsSlice } from '../../../models/app-store';
import { Plane, TransformControls } from "@react-three/drei";
import { IAppStore } from "../../../models/app-store";
import { IMesh } from "../../../models/room";
import { useDispatch } from "react-redux";
import { TAppDispatch } from "../../../store/app-store";
import { storeRoomsSliceActions } from "../../../store/slices/rooms/rooms-slice";

export default function App() {
    const starsEnabled = useSelector((state: IStoreRoomsSlice) => state.selectedRoom?.state?.stars || false);

    const meshes = useSelector((store: IAppStore) => store.rooms.selectedRoom?.state.meshes);
    const selectedMeshID = useSelector((store: IAppStore) => store.rooms.selectedRoom?.state.selectedMeshId);
    const dispatch = useDispatch<TAppDispatch>();

    console.log(selectedMeshID)
    const handleMeshSelection = (meshID:IMesh['id']) => {
      dispatch(storeRoomsSliceActions.setSelectedMeshId(meshID))
      console.log(meshID)
    }

    return (
      <Canvas style={{height:"100vh"}}>
        <OrbitControls />
        <Sky />
        {starsEnabled && <Stars />}
        <Plane
            args={[10, 10, 10, 10]}
            rotation={[1.5 * Math.PI, 0, 0]}
            position={[0, 0, 0]}
         >
            <meshStandardMaterial attach="material" color="#f9c74f" wireframe />
        </Plane>
        {meshes && Object.values(meshes).map((mesh) => {

            const show = mesh.id === selectedMeshID
            console.log(mesh.id, show)

            return (
            <>
              <TransformControls key={mesh.id} showX={show} showY={show} showZ={show} onClick={() => handleMeshSelection(mesh.id)}>              
                <mesh 
                    position={mesh.position}
                    rotation={mesh.rotation}
                    scale={mesh.scale}
                    
                >
                    <boxGeometry />
                    <meshStandardMaterial color="hotpink" />

                </mesh>
              </TransformControls>
              <TransformControls key={mesh.id+ 'fdgdfgs'} showX={show} showY={show} showZ={show} onClick={() => handleMeshSelection(mesh.id)}>              
                <mesh 
                    position={[mesh.position[0], 10, 0]}
                    rotation={mesh.rotation}
                    scale={mesh.scale}
                    
                >
                    <boxGeometry />
                    <meshStandardMaterial color="hotpink" />

                </mesh>
              </TransformControls>
            </>
            );
        })}
      </Canvas>
    );
  }