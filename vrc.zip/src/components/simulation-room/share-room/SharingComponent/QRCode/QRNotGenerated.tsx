const QRNotGenerated = () =>
{
    return (
        <>
                <h2 className="font-bold text-6xl text-center my-10">
                    No QR Code
                    <br/>
                    Generated Yet
                </h2>
        </>
    )
}

export default QRNotGenerated;